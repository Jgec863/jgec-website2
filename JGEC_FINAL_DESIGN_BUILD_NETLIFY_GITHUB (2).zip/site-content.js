(()=>{
'use strict';
// Public website renderer for content edited through Pages CMS. It does not expose any admin credentials.
const ES=document.documentElement.lang==='es';
const lang=ES?'es':'en';
const root=ES?'../':'';
const path=location.pathname.split('/').filter(Boolean).pop()||'index.html';
const page=path==='es'?'index':path.replace(/\.html$/i,'');
const mount=document.querySelector('[data-cms-media-mount]');
const compareMount=document.querySelector('[data-cms-comparison-mount]');
const txt=(node,value)=>{if(node&&typeof value==='string'&&value.trim())node.textContent=value.trim();};
function secureURL(input){
 if(typeof input!=='string'||!input.trim())return '';
 try{const url=new URL(input.trim(),location.href);if(!['http:','https:'].includes(url.protocol))return '';
 if(input.startsWith('/')&&!input.startsWith('//'))return url.pathname+url.search;
 return url.href;
 }catch{return '';}
}
function imageURL(input){const url=secureURL(input);return url;}
function videoURL(input){
 const url=secureURL(input);if(!url)return null;
 try{
 const u=new URL(url,location.href),host=u.hostname.toLowerCase();
 if(host==='youtube.com'||host==='www.youtube.com'||host==='m.youtube.com'||host==='youtube-nocookie.com'||host==='www.youtube-nocookie.com'){
   const raw=(u.pathname.startsWith('/shorts/')||u.pathname.startsWith('/embed/'))?u.pathname.split('/')[2]:u.searchParams.get('v');
   if(raw&&/^[A-Za-z0-9_-]{11}$/.test(raw))return {kind:'embed',src:'https://www.youtube-nocookie.com/embed/'+raw};
 }
 if(host==='youtu.be'||host==='www.youtu.be'){
   const raw=u.pathname.split('/')[1];if(raw&&/^[A-Za-z0-9_-]{11}$/.test(raw))return {kind:'embed',src:'https://www.youtube-nocookie.com/embed/'+raw};
 }
 if(host==='vimeo.com'||host==='www.vimeo.com'||host==='player.vimeo.com'){
   const raw=u.pathname.split('/').filter(Boolean).pop();if(/^\d+$/.test(raw||''))return {kind:'embed',src:'https://player.vimeo.com/video/'+raw};
 }
 if(/\.(mp4|webm)(\?.*)?$/i.test(u.pathname+u.search))return {kind:'file',src:u.href};
 }catch{}
 return null;
}
function dom(tag,className,text){const e=document.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=String(text);return e;}
function validItem(i){if(!i||i.enabled===false)return null;
 if(i.type==='image')return imageURL(i.image)?{...i,url:imageURL(i.image),kind:'image'}:null;
 const link=videoURL(i.video_url)||videoURL(i.video_file);
 return link?{...i,url:link.src,kind:link.kind}:null;
}
function photoCard(item){
 const art=dom('article','cms-media-card');
 if(item.kind==='image'){
   const btn=dom('button','cms-image-button');btn.type='button';btn.dataset.lightboxImage=item.url;btn.dataset.caption=item.title||item.alt||'';btn.setAttribute('aria-label',ES?'Ampliar imagen':'Enlarge photo');
   const img=dom('img');img.src=item.url;img.alt=item.alt||item.title||(ES?'Foto del proyecto':'Project photograph');img.loading='lazy';img.decoding='async';btn.append(img);art.append(btn);
 }else{
   const box=dom('div','cms-video-frame');
   if(item.kind==='embed'){
     const iframe=dom('iframe');iframe.src=item.url;iframe.title=item.title||(ES?'Video del proyecto':'Project video');iframe.loading='lazy';iframe.allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; web-share';iframe.allowFullscreen=true;iframe.referrerPolicy='strict-origin-when-cross-origin';box.append(iframe);
   }else{
     const vid=dom('video');vid.controls=true;vid.preload='metadata';vid.playsInline=true;const poster=imageURL(item.poster);if(poster)vid.poster=poster;const source=dom('source');source.src=item.url;source.type=/\.webm(?:\?|$)/i.test(item.url)?'video/webm':'video/mp4';vid.append(source);box.append(vid);
   }
   art.append(box);
 }
 if(item.title||item.description){const text=dom('div','cms-media-caption');if(item.title)text.append(dom('h3','',item.title));if(item.description)text.append(dom('p','',item.description));art.append(text);}
 return art;
}
function renderSections(data){if(!mount)return;
 const groups=Array.isArray(data.sections)?data.sections:[];
 const visible=groups.filter(s=>s&&s.enabled!==false&&Array.isArray(s.items)&&s.items.some(i=>validItem(i)));
 if(!visible.length){mount.replaceChildren();mount.hidden=true;return;}
 const frag=document.createDocumentFragment();
 visible.forEach((g,n)=>{
   const section=dom('section','section cms-gallery-section '+(n%2?'white':'soft'));
   const container=dom('div','container');
   if(g.title||g.description){const head=dom('div','section-heading');const text=dom('div');if(g.title)text.append(dom('h2','',g.title));head.append(text);if(g.description)head.append(dom('p','',g.description));container.append(head);}
   const layout=['grid','featured','carousel'].includes(g.layout)?g.layout:'grid';
   const grid=dom('div','cms-media-grid '+layout);grid.setAttribute('aria-label',g.title||(ES?'Galería de proyectos':'Project gallery'));
   (g.items||[]).map(validItem).filter(Boolean).forEach(item=>grid.append(photoCard(item)));
   if(layout==='carousel'&&grid.children.length>1){
     const control=dom('div','cms-gallery-controls');const prev=dom('button','cms-arrow','‹');const next=dom('button','cms-arrow','›');prev.type=next.type='button';prev.setAttribute('aria-label',ES?'Anterior':'Previous');next.setAttribute('aria-label',ES?'Siguiente':'Next');
     prev.onclick=()=>grid.scrollBy({left:-(grid.firstElementChild?.getBoundingClientRect().width||320)+-18,behavior:'smooth'});
     next.onclick=()=>grid.scrollBy({left:(grid.firstElementChild?.getBoundingClientRect().width||320)+18,behavior:'smooth'});
     control.append(prev,next);container.append(control);
   }
   container.append(grid);section.append(container);frag.append(section);
 });
 mount.replaceChildren(frag);mount.hidden=false;
}
function renderComparison(data){if(!compareMount)return;
 const c=data.comparison||{};
 const before=imageURL(c.before_image),after=imageURL(c.after_image);
 if(!c.enabled||!before||!after){compareMount.replaceChildren();compareMount.hidden=true;return;}
 const section=dom('section','section white cms-comparison-section'),container=dom('div','container');
 if(c.title)container.append(dom('h2','',c.title));
 const wrap=dom('div','comparison cms-before-after');wrap.setAttribute('data-cms-comparison','');
 const beforeDiv=dom('div','before'),afterDiv=dom('div','after');const a=dom('img'),b=dom('img');a.src=before;a.alt=c.before_label||(ES?'Antes':'Before');b.src=after;b.alt=c.after_label||(ES?'Después':'After');beforeDiv.append(a);afterDiv.append(b);wrap.append(beforeDiv,afterDiv,dom('div','comparison-bar'));
 const input=dom('input');input.type='range';input.min='0';input.max='100';input.value='50';input.setAttribute('aria-label',ES?'Comparar antes y después':'Compare before and after');wrap.append(input);
 const labels=dom('div','labels');labels.append(dom('span','',c.before_label||(ES?'Antes':'Before')),dom('span','',c.after_label||(ES?'Después':'After')));wrap.append(labels);
 const bar=wrap.querySelector('.comparison-bar');input.addEventListener('input',()=>{afterDiv.style.clipPath=`inset(0 0 0 ${input.value}%)`;bar.style.left=input.value+'%';});input.dispatchEvent(new Event('input'));
 container.append(wrap);section.append(container);compareMount.replaceChildren(section);compareMount.hidden=false;
}
function renderHero(data){
 const title=document.querySelector('[data-cms-hero-title]');
 if(title&&typeof data.hero_title==='string'&&data.hero_title.trim()){
  if(document.querySelector('.hero')&&/COMMERCIAL ELECTRICAL DESIGN-BUILD|DISEÑO Y CONSTRUCCIÓN ELÉCTRICA/i.test(data.hero_title)){
    const parts=data.hero_title.trim().split(/\s+/);const lines=(lang==='es')?['DISEÑO Y','CONSTRUCCIÓN','ELÉCTRICA']:['COMMERCIAL','ELECTRICAL','DESIGN-BUILD'];
    title.replaceChildren(...lines.map(t=>{const s=document.createElement('span');s.className='line';s.textContent=t;return s}));
  }else{title.textContent=data.hero_title.trim();}
 }txt(document.querySelector('[data-cms-hero-intro]'),data.hero_subtitle);
 const u=imageURL(data.hero_image);if(!u)return;
 const bg=document.querySelector('[data-cms-hero-bg]');
 if(bg)bg.style.backgroundImage=`linear-gradient(90deg,rgba(7,25,37,.97) 0%,rgba(10,29,42,.88) 46%,rgba(9,27,39,.35) 100%),url("${u.replaceAll('"','%22')}")`;
 else{const p=document.querySelector('.pagehero');if(p){p.style.backgroundImage=`linear-gradient(90deg,rgba(8,28,43,.96),rgba(9,33,48,.76)),url("${u.replaceAll('"','%22')}")`;p.classList.add('cms-hero-photo');}}
}
const dataURL=root+'content/'+lang+'/'+page+'.json';
if(mount||compareMount)fetch(dataURL,{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error('Content not available');return r.json();}).then(data=>{if(!data||typeof data!=='object')return;renderHero(data);renderSections(data);renderComparison(data);}).catch(error=>{console.warn('JGEC content: displaying included default page.',error);});
})();
