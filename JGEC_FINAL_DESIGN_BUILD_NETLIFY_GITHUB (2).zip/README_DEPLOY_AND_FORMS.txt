JGEC FINAL WEBSITE — GITHUB / NETLIFY / PAGES CMS
==============================================
1. BACK UP your existing GitHub repo first. The user's existing deployment may include newer edits.
2. In your PRIVATE GitHub repository: Jgec863/jgec-website, REPLACE old site files with contents of this ZIP (NOT the ZIP file itself). Make sure index.html, style.css, site.js, netlify.toml, content/, and .pages.yml are in the repository root. Delete obsolete solar.html, es/solar.html, and any old solar content files or older form-handling scripts that conflict. Do not remove unrelated current assets without checking references.
3. Commit changes to branch main. Netlify should automatically deploy the connected repository. Build command EMPTY; publish directory ".".
4. Netlify dashboard -> JGEC project -> Forms -> confirm Form detection is enabled. A fresh deployment is needed to detect form changes. Form name: jgec-project (same on English and Spanish pages). There is NO solar form.
5. Netlify -> Forms -> Submission notifications -> Add email notification for ALL forms to Jamesgoffeelectrical863@gmail.com. This is a Netlify account setting, not stored in the website.
6. Test the LIVE deployed /contact and /es/contact: name, phone, email, service, city, description (no file first), submit. Confirm the success message appears on SAME page; check Netlify -> Forms -> Verified submissions and Gmail Inbox/Spam. Then test one small JPG or PDF below 6 MB. TEST WITH A REAL SUBMISSION; local mocks cannot prove live Netlify acceptance/delivery.
7. Project and gallery content is editable via https://app.pagescms.org with GitHub auth. Media galleries are hidden automatically if empty. The eight original photographs are byte-for-byte copies of the user supplied files; don't edit or replace them.
8. Domain DNS stays at GoDaddy. GitHub must remain private. Netlify remains the hosting platform.
CONTACT NUMBERS: Office 863-604-9339 / James direct 863-316-2997. Both tap to call in the call chooser.
LICENSE: ER13014742. No claim of statewide licensure; each project needs applicable jurisdictional authority verified.
FORM BEHAVIOR: standard Netlify HTML static form marked data-netlify=true, honeypot field, hidden form-name, POST to root via AJAX using FormData (no Content-Type header) and inline success/error. Native fallback action=/thank-you (extensionless; page is present). 6MB per single image/PDF to remain under Netlify's 8MB request cap.
IF FORM FAILS LIVE: Netlify Forms -> detection and Verified submissions; browser network status for POST /; published deploy content; spam. Avoid guessing that an email notification setting fixes POST errors.
NO SOLAR FORCE, NO PROMOTIONS, NO ADMIN PROMOTION PANEL.
DESIGN: original orange-bolt JGEC mark, large uppercase headings, restrained marketing language, responsive layouts; decorative electrical-plan SVG is not an engineering drawing. Holiday lighting illustration is a concept, not an actual completed project.
