(()=>{'use strict';
 document.documentElement.classList.add('kinetic');
 const es=document.documentElement.lang==='es';
 const nav=document.querySelector('.main-nav');const toggle=document.querySelector('[data-menu-toggle]');
 if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?(es?'Cerrar menú':'Close menu'):(es?'Abrir menú':'Open menu'));});nav.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{nav.classList.remove('open');toggle.setAttribute('aria-expanded','false')}));}
 const callDialog=document.getElementById('call-dialog');document.querySelectorAll('[data-open-call]').forEach(button=>button.addEventListener('click',()=>{if(callDialog&&callDialog.showModal)callDialog.showModal();else location.href='tel:+18636049339'}));
 document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog')?.close()));
 document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();}));
 const lb=document.getElementById('lightbox');const lbImg=lb?.querySelector('img');const lbCaption=lb?.querySelector('[data-lightbox-caption]');
 document.addEventListener('click',event=>{const button=event.target.closest('[data-lightbox-image]');if(!button||!lb||!lbImg)return;const src=button.getAttribute('data-lightbox-image');if(!src)return;lbImg.src=src;lbImg.alt=button.dataset.caption||'';if(lbCaption)lbCaption.textContent=button.dataset.caption||'';lb.showModal();});
 if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){document.documentElement.classList.add('js-reveal');const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}}),{threshold:.08});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));}
 const form=document.getElementById('jgec-quote-form');if(!form)return;
 const status=document.getElementById('form-status');const submit=form.querySelector('[type=submit]');
 function msg(kind,text){status.className='form-status '+kind;status.setAttribute('role',kind==='error'?'alert':'status');status.textContent=text;status.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'nearest'});}
 form.addEventListener('submit',async event=>{
  event.preventDefault();if(!form.reportValidity())return;
  const file=form.querySelector('[name="project_file"]')?.files?.[0];
  if(file&&file.size>6*1024*1024){msg('error',es?'El archivo supera el límite recomendado de 6 MB. Seleccione uno más pequeño o llámenos.':'The attachment exceeds the 6 MB limit. Please choose a smaller file or call us.');return;}
  const fd=new FormData(form);if(!fd.get('form-name'))fd.set('form-name','jgec-project');
  const original=submit.textContent;submit.disabled=true;submit.textContent=es?'ENVIANDO…':'SENDING…';status.className='form-status';status.removeAttribute('role');status.textContent='';
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),29000);
  try{
   // Netlify's documented static-form submission pattern: POST FormData to '/' with NO Content-Type header.
   // Preserves files and the form-name field; avoids redirecting to a potentially missing thank-you URL.
   const response=await fetch('/',{method:'POST',body:fd,signal:controller.signal,headers:{'Accept':'text/html'}});
   if(!response.ok)throw new Error('HTTP '+response.status);
   form.reset();msg('success',es?'Solicitud enviada. Gracias. Revisaremos su proyecto y nos comunicaremos con usted.':'Request sent. Thank you. We’ll review your project and contact you.');
  }catch(err){console.warn('JGEC form submission was not confirmed:',err);msg('error',es?'No pudimos confirmar el envío. Por favor llame a la oficina al 863-604-9339 o directamente a James al 863-316-2997.':'We could not confirm your request was sent. Please call the office at 863-604-9339 or James directly at 863-316-2997.');}
  finally{clearTimeout(timer);submit.disabled=false;submit.textContent=original;}
 });
})();
